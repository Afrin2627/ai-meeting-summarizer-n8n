# AI Meeting Summarizer — n8n + Slack/Gmail + OpenAI/OpenRouter

Turn raw meeting transcripts into **clean summaries + action items + risks** and auto-send them to **Slack** (or Gmail). Built with **n8n**.

> ✅ Works with **OpenAI** or **OpenRouter (free alternative)**  
> ✅ Includes Slack message template  
> ✅ Importable n8n workflow (add yours to `/workflow/`)  

---

## 🚀 What it does
1. **Input**: Meeting transcript (paste or .txt from Google Drive).  
2. **Process**: n8n calls an LLM to produce JSON → `{ summary, action_items[], risks[] }`.  
3. **Output**: Posts a nicely formatted message to **Slack** (or sends email via **Gmail**).

---

## 🧩 Architecture
```
Manual Trigger (or Google Drive Trigger)
  → Set Transcript (title + transcript text)
  → LLM (OpenAI node or HTTP Request to OpenRouter)
  → Parse JSON (Code node)
  → Slack: Send Message  (or Gmail: Send Email)
```

---

## 🔑 Credentials you’ll need (stored **only** inside n8n)
- **OpenAI** API key *(paid; easiest)* **or** **OpenRouter** API key *(free)*  
- **Slack** Bot OAuth token (xoxb-…); in n8n use **Slack OAuth2 API** credential  
- *(Optional)* **Gmail** OAuth credential if you prefer email instead of Slack

> **Never commit keys** to GitHub. Keep them in n8n Credentials only.

---

## 🛠️ Quickstart (import your workflow)
1. In n8n, build the workflow (or **Export** it via `… → Export → Download`).
2. Put the exported JSON in this repo at: `/workflow/workflow.json` (do **not** include credentials).
3. Add screenshots of your canvas and Slack output to `/screenshots/`.

---

## 🔧 Node configuration (copy‑paste friendly)

### 1) Set Node (name: `Set Transcript`)
- `meeting_title` (String) → e.g., `Weekly Growth Sync – 2025-09-04`
- `transcript` (String) → paste sample from `sample_transcript.txt`

### 2A) OpenAI Node (Message a Model)
- **Model**: `gpt-4o-mini` *(or `gpt-3.5-turbo`)*  
- **Temperature**: `0.0`  
- **Messages**:  
  - **System**:
    ```
    You are a meeting notes assistant. Return ONLY strict JSON matching this schema:
    {
      "summary": "string (markdown bullets)",
      "action_items": [
        {"owner":"string or null","task":"string","due":"YYYY-MM-DD or null"}
      ],
      "risks": ["string"]
    }
    Do not include code fences or extra text. If owners/dates are missing, set them to null.
    ```
  - **User**:
    ```
    Title: {{$json.meeting_title}}

    Transcript:
    {{$json.transcript}}
    ```

### 2B) OpenRouter (HTTP Request Node) — **free alternative**
- **Method**: `POST`  
- **URL**: `https://openrouter.ai/api/v1/chat/completions`  
- **Headers**:  
  - `Authorization`: `Bearer YOUR_OPENROUTER_KEY`  
  - `Content-Type`: `application/json`  
- **Body (JSON)**:
  ```json
  {
    "model": "openai/gpt-3.5-turbo",
    "messages": [
      {
        "role": "system",
        "content": "You are a meeting notes assistant. Return ONLY strict JSON matching this schema: {"summary": "string (markdown bullets)", "action_items": [{"owner":"string or null","task":"string","due":"YYYY-MM-DD or null"}], "risks": ["string"]} Do not include code fences or extra text. If owners/dates are missing, set them to null."
      },
      {
        "role": "user",
        "content": "Title: {{$json.meeting_title}}\n\nTranscript:\n{{$json.transcript}}"
      }
    ],
    "temperature": 0
  }
  ```

### 3) Code Node (name: `Parse JSON`)
```js
const raw = $json.choices?.[0]?.message?.content || $json.data || $json.text || $json.message || $json;
let obj;
try { obj = typeof raw === "string" ? JSON.parse(raw) : raw; }
catch(e){ throw new Error("LLM did not return valid JSON. Lower temperature or tighten schema."); }

return [{
  meeting_title: $json.meeting_title || "Meeting Notes",
  summary: obj.summary || "",
  action_items: obj.action_items || [],
  risks: obj.risks || []
}];
```

### 4A) Slack Node → **Post Message**
- **Send Message To**: Channel (e.g., `#meeting-updates`)  
- **Message Type**: Simple Text Message  
- **Message**:
  ```
  📌 *{{$json.meeting_title}}*

  *Summary*
  {{$json.summary}}

  *Action Items*
  {{ $json.action_items.map((x,i)=>`${i+1}. ${x.task} ${x.owner?`(@${x.owner})`:''} ${x.due?`(due ${x.due})`:''}`).join('\n') }}

  *Risks*
  {{ $json.risks.length ? $json.risks.map((r,i)=>`${i+1}. ${r}`).join('\n') : '—' }}
  ```

### 4B) Gmail Node → **Send Email** (optional)
Use the same fields; put formatted HTML in the body.

---

## 📸 What to include in this repo
```
.
├── README.md
├── sample_transcript.txt
├── workflow/
│   └── workflow.json           # <— your exported n8n workflow (no credentials)
└── screenshots/
    ├── workflow-canvas.png     # n8n nodes connected
    └── slack-output.png        # message posted by the bot
```

---

## 🧪 Test
1. Run workflow manually.  
2. Verify Slack channel (or email) received the message.  
3. If JSON parse fails → set temperature to `0.0`, recheck the system schema.

---

## 🔒 Security
- Do **not** commit API keys or tokens.  
- Use n8n Credentials vault only.  
- Redact private info in screenshots.

---

## 📝 Resume snippet (copy‑paste)
> Built an AI-powered **meeting summarizer** using **n8n** and **LLMs** to convert transcripts into structured **summaries, action items, and risks**, auto-delivered to **Slack/Gmail**; showcased workflow automation and cross-team enablement.

---

## 📄 License
MIT
